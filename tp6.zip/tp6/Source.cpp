#include<iostream>
using namespace std;
#include"image.h"
#include"album.h"


int main() {
	image* n = new image("20210201", "bbdou", 17, 5);
	n->addmotclee("abdou");
	n->addmotclee("bd");
	//n->Affiche();
	image* m = new image("20201013", "popo", 174, 15);
	m->addmotclee("po");
	m->addmotclee("op");
	//m->Affiche();
	image* s = new image("20201018", "zomo", 187, 51);
	s->addmotclee("zm");
	s->addmotclee("mo");
	//s->Affiche();
	image* z = new image("20201203", "driss", 717, 35);
	z->addmotclee("dr");
	z->addmotclee("iss");
	z->addmotclee("zm");
	//z->Affiche();

	album* nv = new album("album1");
	nv->addimage(n);
	nv->addimage(m);
	nv->addimage(z);
	nv->addimage(s);

	nv->getImages("zm");
	/*cout << *nv;
	nv->tri();
	cout << *nv;*/
	//nv->Affiche();
}
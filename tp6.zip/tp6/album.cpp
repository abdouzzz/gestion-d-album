#include "album.h"



album::album(const string& n):nonAlbum(n) {

}
void album::addimage(image* e) {
	int i = 0;
	MonAlbum.push_back(e);
	while (i<e->gettailletab()) {
			index.emplace(e->getmotcle(i), e);
			i++;
	}
}

void album::tri() {
	
  sort(MonAlbum.begin(), MonAlbum.end() , trichronologique);
	
}
bool trichronologique(image* n, image*s) {
	if (n->getnom() < s->getnom()) {
		return true;
	}
	else {
		return false;
	}
}

//bool & album::operator <(const image& e) {
//	if (this.getnom() < e.getnom()) {
//		return true;
//	}
//	else {
//		return false;
//	}
//}
ostream& operator <<(ostream& o, const album& e) {
	cout << e.nonAlbum;
	for (auto it = e.MonAlbum.begin(); it != e.MonAlbum.end(); it++) {
		(*it)->Affiche();
	}
	return o;
}
void album::Affiche() {
	for (const auto& p : index) {
		cout << p.first << " / " << p.second->getnom() << endl;
	}
}
vector<image*> album::getImages(const std::string& mot) const {
	vector<image*>n;
	auto equal = index.equal_range(mot);
	for (auto it = equal.first; it != equal.second; it++) {
		n.push_back((*it).second);
	}
	for (const auto& item : index) {
		item.second->Affiche();
	}
	return n;
}
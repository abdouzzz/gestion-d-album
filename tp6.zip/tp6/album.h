#pragma once
#include<iostream>
#include<string>
#include "image.h"
#include<vector>
#include<algorithm>
#include<map>
using namespace std;
class album
{
private:
	string nonAlbum;
	vector<image*>MonAlbum;
	multimap<string, image*> index;
public:
	album(const string & n);
	void addimage(image* e);
	void tri();
	string getn() { return nonAlbum; }
	void addmap(image *n);
	void Affiche();
	vector<image*> getImages(const std::string& mot) const;
	friend ostream& operator<<(ostream& o, const album& e);
};
bool trichronologique(image*n,image*s);
ostream& operator<<(ostream& o, const album& e);
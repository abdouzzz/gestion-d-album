#include "image.h"

image::image(const string& e, const string& s, int _x, int _y):Date(e),nom(s),x(_x),y(_y){}
image::image(){}
image::~image(){}
string image::getdate() const { return Date; }
string image::getnom() const { return nom; }
int image::getx() const { return x; }
int image::gety() const { return y; }
void image::Affiche()const {
	cout << "Date :" << getdate() << endl;
	cout << "Nom :" << getnom() << endl;
	cout << "largeur :" << getx() << endl;
	cout << "hauteur :" << gety() << endl;
	cout << "Motcle :  (";
	for (auto it = motcl�.begin(); it != motcl�.end(); it++) {
		cout << (*it)<< ",";
	}
	cout << " )";
	cout << endl << endl;
}
void image::addmotclee(string n) {
	motcl�.push_back(n);
}
string image::getmotcle(int i) {
	return motcl�[i];
}
int image::gettailletab() {
	int z =0;
	for (const auto& p :motcl� ) {
		z++;
	}
	return z;
}

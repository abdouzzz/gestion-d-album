#pragma once
#include<iostream>
#include<string>
#include<vector>
using namespace std;

class image
{
private:
	string Date;
	string nom;
	int x;
	int y;
	vector<string>motcl�;
public:
	image(const string& e, const string& s, int _x, int _y);
	image();
	~image();
	string getdate() const;
	string getnom() const;
	int getx() const;
	int gety() const;
	void Affiche() const;
	string getmotcle(int i) ;
	void addmotclee(string n);
	int gettailletab();
};

